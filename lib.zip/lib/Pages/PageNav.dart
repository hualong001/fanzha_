



import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../Units/MyAppBar.dart';


class PageNav extends StatefulWidget{
  String pageTitle;
  Widget pageBody;
  PageNav({required this.pageTitle, required this.pageBody});

  @override
  State<StatefulWidget> createState() => _PageNavState();
}


class _PageNavState extends State<PageNav>{
  String get pageTitle => widget.pageTitle;
  Widget get pageBody => widget.pageBody;

  //Widget pageBody;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("11111"),),

      body: pageBody,
    );
  }
}