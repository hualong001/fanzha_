




import 'package:anti_fraud/Pages/PageNav.dart';
import 'package:flutter/cupertino.dart';

class Page_about extends StatelessWidget{

  @override
  Widget build(BuildContext context) {
    return PageNav( pageTitle: '', pageBody: PageBody(),);
  }

}


class PageBody extends StatelessWidget{

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text("about"),

      ],
    );
  }
}