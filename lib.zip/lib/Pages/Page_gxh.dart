import 'package:anti_fraud/Units/MyAppBar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../Units/AppBottomSheet.dart';
import '../Words/WordBox.dart';
import '../Words/WordLayout.dart';

List<String> wordlist_kwzd= [
  "什么 金沙河，三死金，田死三， 0田 0三 都是日狗自己造出来的狗循环",
  "日狗最爱一边害人，一边装好人；一边出金狗害人，一边说利狗减金。其实都是日历金",
  "用一个日狗替代另外一个日狗，只会让自己陷入日狗的车轮战与狗循环。",
  "用日狗对付其他人，只是帮日狗做了推广，逼迫别人也养一条日狗， 便宜了日狗， 对自己是完全没有好处",
];

// List<String> wordlistbox_kwzd= [
//   "我猜很多重要人物都见过日狗的这一套，务必让大家了解日狗的诈骗伎俩。",
//   "通常这些新闻的背后都有不少的陷阱，大家去查的时候需要保持清醒，日狗会把不相关的重要人物也拉进来，",
//   "一是让大家畏惧不敢查， 二是栽赃陷害重要人物",
// ];

String str = "坚持做自己，不必受日狗的这个狗循环的影响!";

TextStyle textStyle1 = const TextStyle(
  color: Colors.redAccent,
  fontSize: 25,
  fontWeight: FontWeight.w700,
  fontStyle: FontStyle.normal,
);
TextStyle textStyle2 = const TextStyle(
  color: Colors.black54,
  fontSize: 20,
  fontWeight: FontWeight.w700,
  fontStyle: FontStyle.normal,
);

// TextStyle textBoxStyle1 = const TextStyle(
//   fontSize: 17,
//   color: Colors.black,
//   fontWeight: FontWeight.normal,
//   fontStyle: FontStyle.normal,
// );
// TextStyle textBoxStyle2 = const TextStyle(
//   fontSize: 20,
//   color: Colors.deepPurple,
//   fontWeight: FontWeight.normal,
//   fontStyle: FontStyle.normal,
// );

TextStyle StrStyle = const TextStyle(
  fontSize: 15,
  color: Colors.blueAccent,
  fontWeight: FontWeight.bold,
  fontStyle: FontStyle.normal,
);

class Page_gxh extends StatelessWidget{
  const Page_gxh({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar(pagetitle: "狗循环"),
      floatingActionButton: ShowBottomSheet(),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(10),
        child: Center(
            child: Column(
              children: [
                const SizedBox(height: 10,),
                WordsList(items: wordlist_kwzd, textStyle1: textStyle1, textStyle2: textStyle2,),
                const SizedBox(height: 50,),
                Words(words: str, textStyle: StrStyle,),
              ],
            )
        ),
      )
    );
  }
}
