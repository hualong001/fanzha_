import 'package:anti_fraud/Units/MyAppBar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../Units/AppBottomSheet.dart';
import '../Words/WordBox.dart';
import '../Words/WordLayout.dart';

List<String> wordlist_kwzd= [
  "日本在公共海域排放核废水，无异于对全球沿海国家进行了一次核打击；",
  "相比气候变化等全球性的议题，日本不负责任排放核废水的行为对全球的伤害更大更直接，且无法挽回",
];


List<String> wordlistbox_kwzd= [
  "1.日本不具有安全使用核电站的能力及条件，不具有为核电站承担责任的意愿及能力；",
  "2.各国需要研究对不负责任排放核废水祸害全球行为的惩罚，赔偿及治理，各国应团结一致制止全球祸害-日本；",
  "3.禁止日本海产的出口销售；停止前往日本的旅游线路；增加对日本向外出口以及出行的人和物进行放射性检测，检测费用由日本承担；"
];


TextStyle textStyle1 = const TextStyle(
  color: Colors.redAccent,
  fontSize: 20,
  fontWeight: FontWeight.w700,
  fontStyle: FontStyle.normal,
);
TextStyle textStyle2 = const TextStyle(
  color: Colors.black54,
  fontSize:20,
  fontWeight: FontWeight.w700,
  fontStyle: FontStyle.normal,
);


TextStyle textBoxStyle1 = const TextStyle(
  fontSize: 17,
  color: Colors.black,
  fontWeight: FontWeight.normal,
  fontStyle: FontStyle.normal,
);
TextStyle textBoxStyle2 = const TextStyle(
  fontSize: 15,
  color: Colors.deepPurple,
  fontWeight: FontWeight.normal,
  fontStyle: FontStyle.normal,
);

class Page_hwr extends StatelessWidget{
  const Page_hwr({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar(pagetitle: "核污染"),
      floatingActionButton: ShowBottomSheet(),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(10),
        child: Center(
            child: Column(
              children: [
                const SizedBox(height: 20,),
                WordsList(items: wordlist_kwzd, textStyle1: textStyle1, textStyle2: textStyle2,),
                const SizedBox(height: 20,),
                const Image(width:500,image: AssetImage('assets/images/hwr.png')),
                const SizedBox(height: 20,),
                WordBox(items: wordlistbox_kwzd, textStyle1: textBoxStyle1, textStyle2:textBoxStyle2,),

              ],
            )
        ),
      )
    );
  }
}
