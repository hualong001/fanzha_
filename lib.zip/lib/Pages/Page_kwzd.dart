import 'package:anti_fraud/Units/MyAppBar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../Units/AppBottomSheet.dart';
import '../Units/BottomNav.dart';
import '../Words/WordBox.dart';
import '../Words/WordLayout.dart';
import '../Words/WordList.dart';
import 'MyHomePage.dart';

List<String> wordlist_kwzd= [
  "自封为王",
  "自命为天人",
  "爱给自己贴金",
  "自称霸权"
];

List<String> wordlistbox_kwzd= [
  "日狗这种表现的极其嚣张的自吹，也不完全是狂妄",
  "还有来自内心的自卑与不自信，出门在外害怕被人欺负",
  "只能搞搞宣传自己吹自己，把自己吹成超越一切权势的力量",
  "吓唬一下别人，以此获得生存的筹码..",
  "如果没有人支持自己，还得自己打广告盗用别人的身份支持一下自己"
];

String str = "真的共产党人绝不会自比做“天”，表现的高人一等的样子!";

TextStyle textStyle1 = const TextStyle(
  color: Colors.redAccent,
  fontSize: 48,
  fontWeight: FontWeight.w700,
  fontStyle: FontStyle.normal,
);
TextStyle textStyle2 = const TextStyle(
  color: Colors.blueAccent,
  fontSize: 48,
  fontWeight: FontWeight.w700,
  fontStyle: FontStyle.normal,
);

TextStyle textBoxStyle1 = const TextStyle(
  fontSize: 20,
  color: Colors.black,
  fontWeight: FontWeight.normal,
  fontStyle: FontStyle.normal,
);
TextStyle textBoxStyle2 = const TextStyle(
  fontSize: 20,
  color: Colors.deepPurple,
  fontWeight: FontWeight.normal,
  fontStyle: FontStyle.normal,
);

TextStyle StrStyle = const TextStyle(
  fontSize: 20,
  color: Colors.redAccent,
  fontWeight: FontWeight.bold,
  fontStyle: FontStyle.normal,
);

class Page_kwzd extends StatelessWidget{
  const Page_kwzd({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar(pagetitle: "狂妄自大"),
      floatingActionButton: ShowBottomSheet(),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(10),
        child: Center(
            child: Column(
              children: [
                const SizedBox(height: 10,),
                WordsList(items: wordlist_kwzd, textStyle1: textStyle1, textStyle2: textStyle2,),
                const SizedBox(height: 20,),
                WordBox(items: wordlistbox_kwzd, textStyle1: textBoxStyle1, textStyle2:textBoxStyle2,),
                const SizedBox(height: 20,),
                Words(words: str, textStyle: StrStyle,),
              ],
            )
        ),
      )
    );
  }
}
