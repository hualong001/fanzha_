import 'package:anti_fraud/Units/MyAppBar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../Units/AppBottomSheet.dart';
import '../Words/WordBox.dart';
import '../Words/WordLayout.dart';

List<String> wordlist_kwzd= [
  "冷政治，热经济；阻止和拦截对日本不利的新闻，表面上的一团和气，背地里干的是伤害中国人的事情；",
  "一边想着赚中国人的钱，\n一边想着限制中国的发展；",
];


List<String> wordlistbox_kwzd= [
  "对重要人物无限追捧巴结，表现的及其乖巧；",
  "对底层群众无比残酷，动辄进行恐吓威胁；",
  "对能利用的人毫无底线的诈骗；"
];


TextStyle textStyle1 = const TextStyle(
  color: Colors.redAccent,
  fontSize: 20,
  fontWeight: FontWeight.w700,
  fontStyle: FontStyle.normal,
);
TextStyle textStyle2 = const TextStyle(
  color: Colors.black54,
  fontSize:20,
  fontWeight: FontWeight.w700,
  fontStyle: FontStyle.normal,
);


TextStyle textBoxStyle1 = const TextStyle(
  fontSize: 17,
  color: Colors.black,
  fontWeight: FontWeight.normal,
  fontStyle: FontStyle.normal,
);
TextStyle textBoxStyle2 = const TextStyle(
  fontSize: 15,
  color: Colors.deepPurple,
  fontWeight: FontWeight.normal,
  fontStyle: FontStyle.normal,
);

class Page_lmsd extends StatelessWidget{
  const Page_lmsd({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar(pagetitle: "两面三刀"),
      floatingActionButton: ShowBottomSheet(),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(10),
        child: Center(
            child: Column(
              children: [
                const SizedBox(height: 50,),
                const Image(width:500,image: AssetImage('assets/images/lmsd.png')),
                const SizedBox(height: 50,),
                WordsList(items: wordlist_kwzd, textStyle1: textStyle1, textStyle2: textStyle2,),
                const SizedBox(height: 50,),
                WordBox(items: wordlistbox_kwzd, textStyle1: textBoxStyle1, textStyle2:textBoxStyle2,),

              ],
            )
        ),
      )
    );
  }
}
