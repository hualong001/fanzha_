import 'package:anti_fraud/Units/MyAppBar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../Units/AppBottomSheet.dart';
import '../Words/WordBox.dart';
import '../Words/WordLayout.dart';

List<String> wordlist_kwzd= [
  "日狗总是在中国渲染美国威胁论，",
  "--在美国渲染中国威胁论；",
  "在中国捏造日美同盟，",
  "--在美国捏造中日友好；",
  "日狗还经常诱导少数中国人攻击美国；",
  "--然后又以此为借口诱导美国人攻击中国；",
  "日狗在中国边境旅行团打着爱国的旗号大肆宣扬与其它国家仇恨 ，",
  "--却刻意隐藏日本的罪行；",
  "空手套白狼，日狗把从中国偷窃的拿到美国出售，",
  "--把从美国偷来的拿到中国出售；",
  "日狗爱借助中美的热点人物宣传自己或者伪造关系或者打击自己的敌人；打着别人的旗号打广告宣传自己；打着别人的旗号挑拨仇恨；做坏事的时候还爱把不相关的重要人物拉下水；",
  "--所以看广告也要保持警惕，谨防被日狗误导；",
  "在中美竞争的一些领域，日狗最敏感，最兴奋，",
  "--往往是当事人还没有表态，日狗就开始急不可耐的打着中美双方的幌子互相攻击制造仇恨了；",
  "一边吹捧中国人能打善战做什么列强，",
  "--一边又改口说中国人不好，有侵略性；",
  "不怀好意的吹中贬美或者吹美贬中；"
];

List<String> wordlistbox_kwzd= [
  " 以日狗的狗性，一定会想尽各种办法攀附中美两国，并以大国为跳板，向其他国家渗透。   日狗背地里还总想挑拨中美的仇恨与斗争。",
  "所以说搞好中美关系， 清理日狗， 不是为了别人， 是为了自己；\n不仅是为了自己， 也是为了其他国家不受日狗的侵略。",
];

TextStyle textStyle1 = const TextStyle(
  color: Colors.redAccent,
  fontSize: 17,
  fontWeight: FontWeight.w700,
  fontStyle: FontStyle.normal,
);
TextStyle textStyle2 = const TextStyle(
  color: Colors.black54,
  fontSize: 15,
  fontWeight: FontWeight.normal,
  fontStyle: FontStyle.normal,
);

TextStyle textBoxStyle1 = const TextStyle(
  fontSize: 15,
  color: Colors.black,
  fontWeight: FontWeight.normal,
  fontStyle: FontStyle.normal,
);
TextStyle textBoxStyle2 = const TextStyle(
  fontSize: 22,
  color: Colors.redAccent,
  fontWeight: FontWeight.bold,
  fontStyle: FontStyle.normal,
);

TextStyle StrStyle = const TextStyle(
  fontSize: 15,
  color: Colors.brown,
  fontWeight: FontWeight.bold,
  fontStyle: FontStyle.normal,
);

class Page_tbch extends StatelessWidget{
  const Page_tbch({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar(pagetitle: "挑拨仇恨"),
      floatingActionButton: ShowBottomSheet(),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.all(10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              const SizedBox(height: 10,),
              WordsList(items: wordlist_kwzd, textStyle1: textStyle1, textStyle2: textStyle2,),
              const SizedBox(height: 30,),
              WordBox(items: wordlistbox_kwzd, textStyle1: textBoxStyle1, textStyle2:textBoxStyle2,),
            ],
          ),
        ),
      )
    );
  }
}
