import 'package:anti_fraud/Units/MyAppBar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../Units/AppBottomSheet.dart';
import '../Words/WordBox.dart';
import '../Words/WordLayout.dart';



List<String> wordlistbox_kwzd= [
  "导弹打不到的地方，舆论却能打到。街边小丑，进入电视剧摇身一变当起了王。几条疯狗，捏造虚构几个军事视频，也能搞出千军万马的样子；",
  "现实中做不到的事情，现实中实现不了的关系，拍个电视剧全部实现了。通过电视剧与广告颠倒是非黑白，捏造一个有利于自己诈骗偷窃生存与扩张的环境，这是日狗如此热爱打广告拍电视剧的原因；",
  "日狗大量的钱与军力都用来了打广告搞宣传",
];

String str = "（拍电影，写小说，捏造短视频，编书，编game，拉横幅贴标语…）";

TextStyle textBoxStyle1 = const TextStyle(
  fontSize: 25,
  color: Colors.black,
  fontWeight: FontWeight.normal,
  fontStyle: FontStyle.normal,
);
TextStyle textBoxStyle2 = const TextStyle(
  fontSize: 25,
  color: Colors.deepPurple,
  fontWeight: FontWeight.normal,
  fontStyle: FontStyle.normal,
);

TextStyle StrStyle = const TextStyle(
  fontSize: 20,
  color: Colors.redAccent,
  fontWeight: FontWeight.bold,
  fontStyle: FontStyle.normal,
);

class Page_xjxc extends StatelessWidget{
  const Page_xjxc({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar(pagetitle: "虚假宣传"),
      floatingActionButton: ShowBottomSheet(),
      body: Container(
        padding: EdgeInsets.all(10),
        child: SingleChildScrollView(
            child: Column(
              children: [
                const SizedBox(height: 10,),
                WordBox(items: wordlistbox_kwzd, textStyle1: textBoxStyle1, textStyle2:textBoxStyle2,),
                const SizedBox(height: 50,),
                Words(words: str, textStyle: StrStyle,),
              ],
            )
        ),
      )
    );
  }
}
