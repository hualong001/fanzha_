import 'package:anti_fraud/Units/MyAppBar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../Units/AppBottomSheet.dart';
import '../Words/WordBox.dart';
import '../Words/WordLayout.dart';

List<String> wordlist_kwzd= [
  "第一：日本处于绝境，发展严重依赖外部，所以需要到处找爹，只是各国的爹发现这个日本儿子非常“坑爹”，一边吃爹的，一边偷爹的，还经常打着爹爹的旗号到处作恶，所以各国的爹都提高了警惕；日本把自己逼到了绝境，所以为了避免日本人狗急跳墙，必须要求日本人停止使用核电站，归还或者销毁所有核原料；日本把自己逼到了绝境，所以才急于挑拨其他国家的仇恨甚至战争，自己好坐收渔利，所以我们必须深刻认识到日本的危险性，各国增加相互沟通，拒绝日本挑拨；日本把自己逼到了绝境， 所以干起了恐吓威胁、无限诈骗的勾当，所以需要深刻认识日本人的诈骗套路，拒腐防变，给自己打打预防针。",
  "第二：日本原有的经济技术优势已经完全丧失，人口老龄化趋势加大且无法逆转，巨量且还在激增的债务随时面临破产，这是一个社会发展畸形变态，年轻人少，没有发展前途的国家。但是还是要警惕，日本人经常说中国的老龄化问题，想让中国人解决日本的问题。比如把日本老头送到中国来养老，无疑是把这些老头当炮灰，在中国当寄生虫搞间谍活动，既能缓解日本国内的老龄问题，还可以压榨日本老年人的剩余价值;",
  "第三：不用对日本有什么好的幻想，这是一个曾经侵略中国至今不肯认错甚至有意篡改历史妄想逃避罪行的国家，这是一个一边吞食中国发展红利一边想尽各种办法限制中国发展的国家，这是一个对重要人物无限追捧巴结对底层老百姓无比残酷的两面三刀的国家，这是一个满嘴谎言无限欺诈至今还在不停搞侵略扩张的国家，这是一群没有人性没有尊严的孽畜;",
  "第四：需要认识到，日本具有的无限欺诈的本事，中国还是有不少人被欺骗，还有一些人是被日本利益集团深度捆绑，上了贼船暂时无法脱身。比如那个经常帮日本人骗中国人的“中国李宁”，以及经常帮日本人说情的“知乎”，这是日本经济还没有崩溃的最后一根稻草。我们需要加快自身的内外双循环系统建设，需要让全国人都深刻认识日本的这些状况，一起拒绝日本疯狗，一起打击日本寄生虫，一起抓日本间谍。",
];


String str = "大家终于看清了形式和日本人的嘴脸!";

TextStyle textStyle1 = const TextStyle(
  color: Colors.redAccent,
  fontSize: 15,
  fontWeight: FontWeight.w700,
  fontStyle: FontStyle.normal,
);
TextStyle textStyle2 = const TextStyle(
  color: Colors.black54,
  fontSize: 15,
  fontWeight: FontWeight.w700,
  fontStyle: FontStyle.normal,
);


TextStyle StrStyle = const TextStyle(
  fontSize: 17,
  color: Colors.brown,
  fontWeight: FontWeight.bold,
  fontStyle: FontStyle.normal,
);

class Page_zj extends StatelessWidget{
  const Page_zj({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar(pagetitle: "罪国日本"),
      floatingActionButton: ShowBottomSheet(),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(12),
        child: Center(
            child: Column(
              children: [
                const SizedBox(height: 10,),
                Words(words: str, textStyle: StrStyle,),
                const SizedBox(height: 20,),
                WordsList(items: wordlist_kwzd, textStyle1: textStyle1, textStyle2: textStyle2,),
              ],
            )
        ),
      )
    );
  }
}
