import 'package:anti_fraud/Units/MyAppBar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../Units/AppBottomSheet.dart';
import '../Words/WordBox.dart';
import '../Words/WordLayout.dart';

List<String> wordlist_kwzd= [
  "日狗经常把日本国内的问题与危机转移到其他国家，妄想让其他国家帮忙分担或承受伤害；",
  "打着中国的旗号骗中国人给日狗解决日本危机；",
  "每次攻击日狗，日狗总爱把自己替换为别人（a），转移伤害；",
];


TextStyle textStyle1 = const TextStyle(
  color: Colors.redAccent,
  fontSize: 27,
  fontWeight: FontWeight.w700,
  fontStyle: FontStyle.normal,
);
TextStyle textStyle2 = const TextStyle(
  color: Colors.black54,
  fontSize: 27,
  fontWeight: FontWeight.w700,
  fontStyle: FontStyle.normal,
);



class Page_zywj extends StatelessWidget{
  const Page_zywj({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar(pagetitle: "转移危机"),
      floatingActionButton: ShowBottomSheet(),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(10),
        child: Center(
            child: Column(
              children: [
                const SizedBox(height: 50,),
                WordsList(items: wordlist_kwzd, textStyle1: textStyle1, textStyle2: textStyle2,),
                const SizedBox(height: 50,),
                Image(image: AssetImage('assets/images/zywj.png')),
              ],
            )
        ),
      )
    );
  }
}
