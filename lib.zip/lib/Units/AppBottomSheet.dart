

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'BottomNav.dart';

void main(){
  runApp(
    MaterialApp(
        home: Scaffold(
          body: ShowBottomSheet(),
        ),
    )
  );
}

class ShowBottomSheet extends StatelessWidget{
  @override
  Widget build(BuildContext context) {

    return FloatingActionButton(
      onPressed: (){
        Scaffold.of(context).showBottomSheet(
                (BuildContext context){
              return Container(
                height: 500,
                //color: Colors.lightBlueAccent,
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      //const Text("BottomSheet"),
                      BottomNav(),
                      ElevatedButton(
                        onPressed: (){
                          Navigator.pop(context);
                        },
                        child: const Text('关闭'),)
                    ],
                  ),
                ),
              );
            }
        );
      }, child: Text(style: TextStyle(fontSize: 20),'∧'),
    );
  }
}