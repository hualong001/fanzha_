

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class MyAppBar extends StatelessWidget implements PreferredSizeWidget{
  String pagetitle;
  MyAppBar({super.key, required this.pagetitle});

  @override
  Widget build(BuildContext context) {
    return AppBar(
      title: Text(pagetitle),
      backgroundColor: Theme.of(context).colorScheme.inversePrimary,
    );
  }

  @override
  // TODO: implement preferredSize
  Size get preferredSize => Size.fromHeight(50);
}
