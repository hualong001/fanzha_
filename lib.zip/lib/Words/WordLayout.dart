

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main(){
  List<String> wordlist= ["1","2","3","4"];
  TextStyle testStyle1 = TextStyle(
    fontSize: 48,
    color: Colors.redAccent,
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.normal,
  );
  TextStyle testStyle2 = TextStyle(
    fontSize: 48,
    color: Colors.deepPurple,
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.normal,
  );

  runApp(
    MaterialApp(
      home: Scaffold(
        body: Center(
          child: Column(
            children: [
              SizedBox(height: 100,),
              Text("data"),
              WordsList(items: wordlist, textStyle1: testStyle1,textStyle2: testStyle2,),
            ],
          )
        ),
      ),
    )
  );
}

class WordsList extends StatelessWidget{
  final List<String> items;
  final TextStyle textStyle1;
  final TextStyle textStyle2;
  const WordsList({super.key, required this.items, required this.textStyle1,required this.textStyle2});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: List<Words>.generate(
          //items.length, (index) => Words(words:'${items[index]}', textStyle: textStyle,)
          items.length, (index) => index % 2 ==0
                ? Words(words:'${items[index]}', textStyle: textStyle1,)
                : Words(words:'${items[index]}', textStyle: textStyle2,)
      ),
    );
  }
}

class Words extends StatelessWidget{
  String words;
  TextStyle textStyle;
  Words({required this.words,required this.textStyle});
  @override
  Widget build(BuildContext context) {
    return Text(
      words,
      style: textStyle,
    );
  }
}