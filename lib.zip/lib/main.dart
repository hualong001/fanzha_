import 'package:flutter/material.dart';

import 'Pages/MyHomePage.dart';
import 'Pages/Page_about.dart';
import 'Pages/Page_gxh.dart';
import 'Pages/Page_hwr.dart';
import 'Pages/Page_jgdrz.dart';
import 'Pages/Page_kwzd.dart';
import 'Pages/Page_ljrz.dart';
import 'Pages/Page_lmsd.dart';
import 'Pages/Page_tbch.dart';
import 'Pages/Page_tq.dart';
import 'Pages/Page_tswc.dart';
import 'Pages/Page_wqjd.dart';
import 'Pages/Page_wxzp.dart';
import 'Pages/Page_xjxc.dart';
import 'Pages/Page_xzss.dart';
import 'Pages/Page_zj.dart';
import 'Pages/Page_zywj.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '罪国日本',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.redAccent),
        useMaterial3: true,
      ),
        routes: {
          'home':(context) => MyHomePage(),
          'about':(context) => Page_about(),
          'kwzd': (context) => Page_kwzd(),
          'wqjd': (context) => Page_wqjd(),
          'wxzp': (context) => Page_wxzp(),
          'gxh': (context) => Page_gxh(),
          'ljrz': (context) => Page_ljrz(),
          'tbch': (context) => Page_tbch(),
          'xjxc': (context) => Page_xjxc(),
          'zywj': (context) => Page_zywj(),
          'xzss': (context) => Page_xzss(),
          'jgdrz': (context) => Page_jgdrz(),
          'tq': (context) => Page_tq(),
          'lmsd': (context) => Page_lmsd(),
          'hwr': (context) => Page_hwr(),
          'tswc': (context) => Page_tswc(),
          'zj': (context) => Page_zj(),

        },
        home: MyHomePage(),

    );
  }
}